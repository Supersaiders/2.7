﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2._7upd
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string firstName = "Вешняков";
            string lastName = "Павел";
            string lastNames = "Сергеевич";
            byte age = 20;
            string email = "m5apa@yandex.ru";
            double ball1 =10.5;
            double ball2 = 25.1;
            double ball3 = 33.3;
            string newPatern = "Фамилия: {0} \nИмя: {1} \nОтчество: {2} \nВозраст: {3} \nЕмейл: {4} \nБаллы по программированию: {5} \nБаллы по математике: {6} \nБаллы по физике: {7}";
            Console.WriteLine(newPatern,
                firstName,
                lastName,
                lastNames,
                age,
                email,
                ball1,
                ball2,
                ball3);

            string newPatern2 = "Общий бал:{0}";
            double a = 10.5;
            double b = 25.1;
            double c = 33.3;
            double d = a + b + c;

            Console.WriteLine(newPatern2,
                d);

            string newPatern3 = "Среднее арифметическое значение:{0}";
            float sum= 68.9f;
            float raz = 3f;
            sum/=raz;

            Console.WriteLine(newPatern3,
                sum);

            Console.ReadKey(); 
        }
    }
}
